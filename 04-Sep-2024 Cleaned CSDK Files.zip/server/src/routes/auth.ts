import { Router, Request, Response } from 'express';
import pool from '../config/db';
import bcrypt from 'bcrypt';
import { RowDataPacket } from 'mysql2';

const router = Router();

router.post('/authenticate', async (req: Request, res: Response) => {
  const { email, password } = req.body;

  try {
    console.log('Received email:', email);
    console.log('Received password:', password);

    // Query the database for the user with the provided email
    const [rows] = await pool.query<RowDataPacket[]>(
      'SELECT * FROM signup WHERE `Email` = ?',
      [email]
    );

    console.log('Database query result:', rows);

    // If no user is found, send an error response
    if (rows.length === 0) {
      console.log('No user found with the provided email');
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const user = rows[0] as { Email: string; Password: string };

    console.log('Stored hashed password:', user.Password);

    // Compare the provided password with the stored password hash
    const passwordMatch = await bcrypt.compare(password, user.Password);

    console.log('Password match result:', passwordMatch);

    if (passwordMatch) {
      // If the password matches, send a success response
      console.log('Password match');
      return res.status(200).json({ message: 'Authentication successful' });
    } else {
      // If the password doesn't match, send an error response
      console.log('Password does not match');
      return res.status(401).json({ message: 'Invalid email or password' });
    }
  } catch (error) {
    console.error('Error during authentication:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
