import React, { useEffect } from 'react';
import Highcharts from 'highcharts';
import { useExecuteQuery } from '@sisense/sdk-ui';
import * as DM from '../sample-test';
import { filterFactory, measureFactory } from '@sisense/sdk-data';

const TargetBarChart: React.FC = () => {
  // Execute the query to get the data
  const { data, isLoading, isError } = useExecuteQuery({
    dataSource: DM.DataSource, // Specify your data source
    dimensions: [DM.Fact_Logistics.ShipmentType, DM.Fact_Logistics.Status], // Group by shipment type and status
    measures: [
      measureFactory.count(DM.Fact_Logistics.ROWID), // Number of shipments
    ],
    filters:[
      filterFactory.contains(DM.Dim_Drop_Locations.Drop_Location, 'Chennai')
    ]
  });

  useEffect(() => {
    if (!isLoading && !isError && data) {
      // Extract the unique shipment types (categories)
      const categories = [...new Set(data.rows.map(row => row[0].data))]; // Unique shipment types

      // Initialize shipment arrays for each status
      const shipmentStatusData = {};
      categories.forEach((category) => {
        shipmentStatusData[category] = { Cancelled: 0, Delivered: 0, Pending: 0, Shipment: 0 };
      });

      // Populate shipment data for each status
      data.rows.forEach(row => {
        const shipmentType = row[0].data;
        const status = row[1].data;
        const count = row[2].data;

        // Store the count based on the shipment type and status
        shipmentStatusData[shipmentType][status] = count;
      });

      // Extract data for each status to plot
      const cancelledShipments = categories.map(category => shipmentStatusData[category].Cancelled || 0);
      const deliveredShipments = categories.map(category => shipmentStatusData[category].Delivered || 0);
      const pendingShipments = categories.map(category => shipmentStatusData[category].Pending || 0);
      const shipmentShipments = categories.map(category => shipmentStatusData[category].Shipped || 0);

      Highcharts.chart('target', {
        chart: {
          type: 'column',
        },
        title: {
          text: `Shipment Status Comparison`,
        },
        xAxis: {
          categories, // Use the dynamic categories (Shipment Types)
        },
        yAxis: [{
          min: 0,
          title: {
            text: 'Number of Shipments',
          },
        }],
        legend: {
          shadow: false,
        },
        tooltip: {
          shared: true,
          valueSuffix: ' Shipments',
        },
        plotOptions: {
          column: {
            pointWidth: 75,
            grouping: false, // Disable grouping to allow overlapping
            shadow: false,
            borderWidth: 0,
            pointPadding: 0.2, // Add padding between columns
            groupPadding: 0.1,
          },
        },
        series: [
          {
            name: 'Cancelled',
            color: 'rgba(255,0,0,0.1)',
            data: cancelledShipments,
            
            pointPlacement: -0.2, // Positioning for overlapping
          },
          {
            name: 'Delivered',
            color: 'rgba(0,0,255,0.3)',
            data: deliveredShipments,
           
            pointPlacement: -0.2, // Positioning for overlapping
          },
          {
            name: 'Pending',
            color: 'rgba(0,128,0,0.5)',
            data: pendingShipments,
         
            pointPlacement: -0.2,
          },
          {
            name: 'Shipment',
            color: 'rgba(255,165,0,0.7)',
            data: shipmentShipments,
          
            pointPlacement: -0.2,
          },
        ],
      });
    }
  }, [data, isLoading, isError]);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (isError) {
    return <div>Error loading data</div>;
  }

  return <div id="target" style={{ width: '100%', height: '400px' }}></div>;
};

export default TargetBarChart;
