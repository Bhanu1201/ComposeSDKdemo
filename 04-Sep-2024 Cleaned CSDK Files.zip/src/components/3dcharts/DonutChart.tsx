import React from 'react';
import Highcharts from 'highcharts';
import Highcharts3D from 'highcharts/highcharts-3d';
import HighchartsReact from 'highcharts-react-official';
import styles from '../../Style/DonutChart.module.css';
import { useExecuteQuery } from '@sisense/sdk-ui';
import * as SM from '../../sample-ecommerce';
import { filterFactory, measureFactory } from '@sisense/sdk-data';

// Initialize the 3D module
Highcharts3D(Highcharts);

const DonutChart: React.FC = () => {
    // Execute the query to fetch data
    const { data } = useExecuteQuery({
        dataSource: SM.DataSource,
        dimensions: [SM.Category.Category],
        measures: [measureFactory.sum(SM.Commerce.Revenue)],
        filters:[filterFactory.contains(SM.Category.Category,'')]
    });

    // Transform the data into the format required by Highcharts
    const chartData = data?.rows.map((row: any) => [
        row[0].text, // Category
        row[1].data // Value
    ]) || [];

    const options: Highcharts.Options = {
        chart: {
            type: 'pie',
            options3d: {
                enabled: true,
                alpha: 45
            }
        },
        title: {
            text: 'Revenue by Category',
            align: 'left'
        },
        subtitle: {
            text: '3D donut chart with dynamic data',
            align: 'left'
        },
        plotOptions: {
            pie: {
                innerSize: 100,
                depth: 45
            }
        },
        series: [{
            name: 'Revenue',
            data: chartData
        }]
    };

    return (
        <figure className={styles.highchartsFigure}>
            <HighchartsReact
                highcharts={Highcharts}
                options={options}
            />

        </figure>
    );
};

export default DonutChart;
