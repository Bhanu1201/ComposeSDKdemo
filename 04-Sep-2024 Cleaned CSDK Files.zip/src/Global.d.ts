// global.d.ts
declare module '*.css' {
    const content: { [className: string]: string };
    export default content;
  }
  
  interface Window {
    Threebox: any; // You can use 'any' if you're unsure about the exact type
  }