declare module 'threebox-plugin' {
    const content: any;
    export default content;
}
