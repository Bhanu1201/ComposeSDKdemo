import React, { useEffect, useState } from 'react';
import axios from 'axios';

// Define the types for the component's props
interface EmbedDashboardProps {
  sisenseDomain: string;
  username: string;
  password: string;
  dashboardId: string;
}

const EmbedDashboard: React.FC<EmbedDashboardProps> = ({ sisenseDomain, username, password, dashboardId }) => {
  const [jwtToken, setJwtToken] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Function to fetch the JWT token
    const fetchJwtToken = async () => {
      try {
        const response = await axios.post(`${sisenseDomain}/api/v1/authentication/login`, {
          username: username,
          password: password,
        });
        setJwtToken(response.data.access_token);
      } catch (err) {
        setError('Failed to fetch JWT token');
        console.error('Error generating JWT token:', err);
      }
    };

    fetchJwtToken();
  }, [sisenseDomain, username, password]);

  if (error) {
    return <div>{error}</div>;
  }

  if (!jwtToken) {
    return <div>Loading...</div>;
  }

  // Construct the iframe URL with the JWT token
  const iframeUrl = `${sisenseDomain}/app/main#/dashboards/${dashboardId}/access_token=${jwtToken}?embed=true`;

  return (
    <div>
      <iframe
        id="sisense-dashboard"
        src={iframeUrl}
        width="100%"
        height="600px"
        title="Sisense Dashboard"
        style={{ border: 'none' }}
      ></iframe>
    </div>
  );
};

export default EmbedDashboard;
