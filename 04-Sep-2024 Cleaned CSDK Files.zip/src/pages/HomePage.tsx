import { useState, useEffect } from 'react';
import { Container, Navbar, Nav, FormControl, InputGroup } from 'react-bootstrap';
import { Box, List, ListItem, ListItemText, IconButton, ListItemIcon } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import LanguageIcon from '@mui/icons-material/Language';
import DashboardIcon from '@mui/icons-material/Dashboard';
import StoreIcon from '@mui/icons-material/Store';
import TableChartIcon from '@mui/icons-material/TableChart';
import PersonIcon from '@mui/icons-material/Person';
import LoginIcon from '@mui/icons-material/Login';
import TranslateIcon from '@mui/icons-material/Translate';
import TargetBarChart from '../components/TargetBarChart';
import DonutChart from '../components/3dcharts/DonutChart';
import * as Appdata from '../sample-test';
import { useExecuteQuery } from '@sisense/sdk-ui';
import Select from 'react-select';
import GaugeChart from '../components/Gauge';
import MapWithPieCharts from '../components/MapWithPieCharts';
import Parabolachart from '../components/3dcharts/ParabolaChart';
import FlightRoute from '../components/Flightroute';
import WorldSalesByGender from '../components/WorldSalesByGender';



const HomePage = () => {
    // Fetch Pickup Locations
    const { data: pickupData } = useExecuteQuery({
        dataSource: Appdata.DataSource,
        dimensions: [
            Appdata.Dim_Pickup_Locations.Pickup_Lat,
            Appdata.Dim_Pickup_Locations.Pickup_Lon,
            Appdata.Dim_Drop_Locations.Drop_Lat,
            Appdata.Dim_Drop_Locations.Drop_Lon,
            Appdata.Dim_Pickup_Locations.Pickup_Location,
            Appdata.Dim_Drop_Locations.Drop_Location
        ]
    });

    const [uniquePickupLocations, setUniquePickupLocations] = useState([]);
    const [selectedLocations, setSelectedLocations] = useState([]);


    useEffect(() => {
        if (pickupData && pickupData.rows) {
            // Extract unique pickup locations from the data
            const locations = [...new Set(pickupData.rows.map(row => row[4]?.data))];
            setUniquePickupLocations(locations.map(location => ({ value: location, label: location })));
        }
    }, [pickupData]);


    const handleLocationChange = (selectedOptions) => {
        setSelectedLocations(selectedOptions || []);
    };


    return (
        <div style={{ display: 'flex', backgroundColor: '#F0F3FF' }}>
            {/* Side Panel */}
            <Box
                sx={{
                    width: 250,
                    height: '100vh',
                    backgroundColor: '#f8f9fa',
                    padding: '15px',
                    position: 'fixed',
                    left: 0,
                    top: 0,
                    bottom: 0,
                    boxShadow: '2px 0 5px rgba(0,0,0,0.1)',
                    borderRadius: '15px',
                }}
            >
                <h4 style={{ color: '#344767', fontWeight: 'bold' }}>HORIZON FREE</h4>
                <List>
                    <ListItem button sx={{ '&:hover': { color: '#5B99C2', backgroundColor: '#03346E', borderRadius: '15px' } }}>
                        <ListItemIcon sx={{ color: '#344767', '&:hover': { color: '#6EACDA' } }}>
                            <DashboardIcon />
                        </ListItemIcon>
                        <ListItemText primary="Main Dashboard" />
                    </ListItem>
                    <ListItem button sx={{ '&:hover': { color: '#5B99C2', backgroundColor: '#03346E', borderRadius: '15px' } }}>
                        <ListItemIcon sx={{ color: '#344767', '&:hover': { color: '#5B99C2' } }}>
                            <StoreIcon />
                        </ListItemIcon>
                        <ListItemText primary="IFrames" />
                    </ListItem>
                    <ListItem button sx={{ '&:hover': { color: '#5B99C2', backgroundColor: '#03346E', borderRadius: '15px' } }}>
                        <ListItemIcon sx={{ color: '#344767', '&:hover': { color: '#5B99C2' } }}>
                            <TableChartIcon />
                        </ListItemIcon>
                        <ListItemText primary="Data Tables" />
                    </ListItem>
                    <ListItem button sx={{ '&:hover': { color: '#5B99C2', backgroundColor: '#03346E', borderRadius: '15px' } }}>
                        <ListItemIcon sx={{ color: '#344767', '&:hover': { color: '#5B99C2' } }}>
                            <PersonIcon />
                        </ListItemIcon>
                        <ListItemText primary="Profile" />
                    </ListItem>
                    <ListItem button sx={{ '&:hover': { color: '#5B99C2', backgroundColor: '#03346E', borderRadius: '15px' } }}>
                        <ListItemIcon sx={{ color: '#344767', '&:hover': { color: '#5B99C2' } }}>
                            <LoginIcon />
                        </ListItemIcon>
                        <ListItemText primary="Sign In" />
                    </ListItem>
                    <ListItem button sx={{ '&:hover': { color: '#5B99C2', backgroundColor: '#03346E', borderRadius: '15px' } }}>
                        <ListItemIcon sx={{ color: '#344767', '&:hover': { color: '#5B99C2' } }}>
                            <TranslateIcon />
                        </ListItemIcon>
                        <ListItemText primary="RTL Admin" />
                    </ListItem>
                </List>
            </Box>

            {/* Main Content */}
            <div style={{ marginLeft: 270, width: 'calc(100% - 270px)' }}>
                {/* Sticky Navbar */}
                <Navbar
                    expand="lg"
                    sticky="top"
                    style={{ padding: '10px 20px' }}
                >
                    <Container fluid>
                        <Navbar.Brand href="#home" style={{ color: '#344767', fontWeight: 'bold' }}>
                            Main Dashboard
                        </Navbar.Brand>
                        <div className='mx-end bg-white rounded-5 ps-2 pe-2 pt-1 pb-1'>
                            <Navbar.Toggle aria-controls="basic-navbar-nav" />
                            <Navbar.Collapse id="basic-navbar-nav">
                                <InputGroup className="" style={{ maxWidth: '300px' }}>
                                    <InputGroup.Text id="basic-addon1" style={{ borderRadius: '20px 0px 0px 20px', border: 'none', backgroundColor: '#B5C0D0' }}>
                                        <SearchIcon />
                                    </InputGroup.Text>
                                    <FormControl
                                        placeholder="Search..."
                                        aria-label="Search"
                                        aria-describedby="basic-addon1"
                                        style={{ borderRadius: '0 20px 20px 0', border: 'none', backgroundColor: '#B5C0D0' }}
                                    />
                                </InputGroup>
                                <Nav className="ml-auto" style={{ display: 'flex', alignItems: 'center' }}>
                                    <IconButton>
                                        <LanguageIcon style={{ color: '#344767' }} />
                                    </IconButton>
                                    <IconButton>
                                        <NotificationsNoneIcon style={{ color: '#344767' }} />
                                    </IconButton>
                                    <IconButton>
                                        <AccountCircleIcon style={{ color: '#344767' }} />
                                    </IconButton>
                                </Nav>
                            </Navbar.Collapse>
                        </div>
                    </Container>
                </Navbar>

                {/* Multi-Select Dropdowns */}
                <Container fluid style={{ padding: '20px', backgroundColor: '' }}>
                    <div className='mb-3'>
                        <Select
                            isMulti
                            options={uniquePickupLocations}
                            onChange={handleLocationChange}
                            placeholder="Select Pickup Locations"
                            value={selectedLocations}
                        />
                    </div>
                    <div className='mb-3'>
                        <Select
                           
                        />
                    </div>

                    <div className='col-12 d-flex flex-wrap'>

                        <div className='col-12'>
                            <div className='col-4 p-2'>
                                <GaugeChart />
                            </div>
                        </div>

                        <div className='col-lg-6 col-md-6 col-sm-12 col-12 p-2'>
                            <TargetBarChart />
                        </div>

                        <div className='col-lg-6 col-md-6 col-sm-12 col-12 p-2'>
                            <MapWithPieCharts />
                        </div>

                        <div className='col-lg-6 col-md-6 col-sm-12 col-12 p-2'>
                            <DonutChart />
                        </div>

                        <div className='col-lg-6 col-md-6 col-sm-12 col-12 p-2'>
                            <WorldSalesByGender/>
                        </div>
                    </div>

                    
                    <div className='d-flex' >
                        <div className='col-6 p-2'>
                            <Parabolachart selectedLocations={selectedLocations} />
                        </div>

                        <div className='col-6 p-2'>
                            <FlightRoute selectedLocations={selectedLocations} />
                        </div>
                    </div>
                </Container>
            </div>
        </div>
    );
};

export default HomePage;