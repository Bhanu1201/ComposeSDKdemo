import { useEffect, useState, useRef } from 'react';
import Highcharts from 'highcharts';
import HighchartsMap from 'highcharts/modules/map';
import dataModule from 'highcharts/modules/data';
import exportingModule from 'highcharts/modules/exporting';
import offlineExportingModule from 'highcharts/modules/offline-exporting';
import seriesOnPoint from 'highcharts/modules/series-on-point';
import accessibilityModule from 'highcharts/modules/accessibility';
import { useExecuteQuery } from '@sisense/sdk-ui';
import * as AV from '../Aviation';
import { measureFactory } from '@sisense/sdk-data';

// Initialize required modules
HighchartsMap(Highcharts);
dataModule(Highcharts);
exportingModule(Highcharts);
offlineExportingModule(Highcharts);
seriesOnPoint(Highcharts);
accessibilityModule(Highcharts);

const Testpiemap = () => {
    const [mapData, setMapData] = useState(null);
    const chartRef = useRef(null);

    // Fetch data from the query
    const { data } = useExecuteQuery({
        dataSource: AV.DataSource,
        dimensions: [AV.CountrySales.Country],
        measures: [
            measureFactory.sum(AV.CountrySales.Sales)
        ],
        filters: []
    });

    console.log("pie", data);

    // Fetch map data only once
    useEffect(() => {
        const fetchMapData = async () => {
            try {
                const response = await fetch('https://code.highcharts.com/mapdata/custom/world.topo.json');
                const fetchedMapData = await response.json();
                setMapData(fetchedMapData);
            } catch (error) {
                console.error('Error fetching map data:', error);
            }
        };

        fetchMapData();
    }, []); // Empty dependency array ensures this runs only once

    // Initialize or update the chart
    useEffect(() => {
        if (!data || !mapData) return;

        // Clean up previous chart instance
        if (chartRef.current) {
            chartRef.current.destroy();
            chartRef.current = null;
        }

        // Initialize the map chart
        const Mapchart = Highcharts.mapChart('Testpie', {
            chart: {
                animation: true,
            },
            accessibility: {
                description: 'Map showing country sales.',
            },
            mapNavigation: {
                enabled: true,
            },
            title: {
                text: 'Country Sales Data',
                align: 'left',
            },
            plotOptions: {
                map: {
                    dataLabels: {
                        enabled: true,
                        formatter: function () {
                            const countryData = data.rows.find(row => row[0].data === this.point.name);
                            const sales = countryData ? countryData[1].data : 'N/A';
                            return `${this.point.name}<br/>Sales: ${sales}`;
                        },
                    },
                },
            },
            series: [
                {
                    mapData,
                    name: 'Countries',
                    joinBy: ['name', 'id'], // Ensure to match by name or id based on your data
                    keys: ['name'], // Keys should correspond to your data's identifiers
                    borderColor: '#FFF',
                    tooltip: {
                        pointFormatter: function () {
                            const countryData = data.rows.find(row => row[0].data === this.name);
                            const sales = countryData ? countryData[1].data : 'N/A';
                            return `<b>${this.name}</b><br/>Sales: ${sales}`;
                        },
                    },
                },
                {
                    name: 'Connectors',
                    type: 'mapline',
                    color: 'rgba(130, 130, 130, 0.5)',
                    zIndex: 5,
                    showInLegend: false,
                    enableMouseTracking: false,
                    accessibility: {
                        enabled: false,
                    },
                },
            ],
        });

        chartRef.current = Mapchart;
    }, [data, mapData]); // Ensure this runs when both data and mapData are available

    return (
        <div>
            <div id="Testpie" style={{ minWidth: '320px', maxWidth: '800px', height: '400px', padding: '2px' }} />
        </div>
    );
};

export default Testpiemap;
